﻿namespace winPEAS.Info.NetworkInfo.Enums
{
    public enum Protocol
    {
        TCP,
        UDP
    }
}
