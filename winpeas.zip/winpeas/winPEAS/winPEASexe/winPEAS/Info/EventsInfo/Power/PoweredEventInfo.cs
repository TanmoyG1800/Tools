﻿using System;

namespace winPEAS.Info.EventsInfo.Power
{
    internal class PowerEventInfo
    {
        public DateTime DateUtc { get; set; }
        public string Description { get; set; }
    }
}
